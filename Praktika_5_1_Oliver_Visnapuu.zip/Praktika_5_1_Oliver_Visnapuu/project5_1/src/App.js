import React, { Component } from "react";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom"; //Switch vana versiooniga
import axios from 'axios';
import './App.css';
import RoomSensors from '../src/components/roomsensors'; //praktika 4 DB päring

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      rooms: [],
    };
  }

  componentDidMount() {
    axios.get('http://localhost:8000/api/rooms')
      .then(res => {
        this.setState({ rooms: res.data.rooms });
      })
      .catch(function (error) {
        console.log(error);
      })
  }

 render() {
    const { rooms } = this.state;
    console.log(rooms);
    return (
      <Router>
        <div className="App">
          <header>
            <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
              <h1>Project:</h1>
              <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav mr-auto">
                  {rooms.map(r => (
                    <li className="nav-item">
                      <Link className="nav-link" to={`/room/${r.room}`}>{r.room}</Link>
                    </li>
                  ))}
                </ul>
              </div>
            </nav>
          </header>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <Routes> 
                  <Route path="/room/:number" component={RoomSensors} />
                </Routes>
              </div>
            </div>
          </div>
        </div>
      </Router>
    );
  }

};

// Switch -> Routes
//<a className="navbar-brand">Project: </a>

//export default App;
